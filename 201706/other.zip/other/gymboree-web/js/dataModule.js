/**
 * Created by jiayi.hu on 3/22/17.
 */
var dataModule = {
    url:{
        centerName: "http://jbb.gemii.cc/"+"EnterGroup/noauth/user/centre?robotID=",
        phoneNumber:"http://jbb.gemii.cc/"+"EnterGroup/noauth/user/phoneCode",
        userInfo:"http://jbb.gemii.cc/"+"EnterGroup/noauth/user/info",
    },
    postUserInfo:function (Data) {
        var url = this.url.userInfo ;
        var arraydata;
        $.ajax({
            data: Data,
            type: "POST",
            url: url,
            dataType: "json",
            async: false,
            cache: false,
            beforeSend:function () {
                $("#submit").text("提交中");
            },
            success: function (json) {
                arraydata = eval(json);
            },
            error: function () {
                alert("请求出错");
            },
            complete:function () {
                 $("#submit").text("提交");
            }
        });
        return arraydata;
    },
    postPhoneNumber:function (phoneNumber) {
        var url = this.url.phoneNumber ;
        var arraydata;
        $.ajax({
            data: {"phoneNumber":phoneNumber},
            type: "POST",
            url: url,
            dataType: "json",
            cache: false,
            beforeSend:function () {
                $("input[id=telephone]").attr("readonly",true);
                $("#sendVerifyCode").val("发送中");
            },
            success: function (json) {
                arraydata = eval(json);
                eventFunctions.sendVerifyCode();
            },
            error: function () {
                alert("请求出错,请刷新重试");
            },
            complete:function () {
                $("input[id=telephone]").removeAttr("readonly");
            }
        });
        return arraydata;
    }
}