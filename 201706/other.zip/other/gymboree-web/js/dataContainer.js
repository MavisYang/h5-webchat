/**
 * Created by jiayi.hu on 3/17/17.
 */
var d = new Date();
var day = d.getDate();
var month = d.getMonth() + 1;
var year = d.getFullYear();
new DateSelector({
    input: 'babyBirth',//点击触发插件的input框的id
    container: 'dataContainer',//插件插入的容器id
    type: 0,
    param: [1, 1, 1, 0, 0],
    beginTime: [2000, 1, 1],
    endTime: [2050, 12, 12],
    recentTime: [year, month, day],
    success: function (arr) {
        console.log(arr);
        // if (arr.length == 3) {
        //     $("#fill_content_text>span").text(arr[0] + "-" + arr[1] + "-" + arr[2]);
        // }
        controller.handleBirChange(arr);
    }//回调
});
new MultiPicker({
    input: 'babyGender',//点击触发插件的input框的id
    container: 'genderContainer',//插件插入的容器id
    jsonData:[{"id":0,"value": "男"},{"id":1,"value": "女"},{"id":2,"value":"未知"}],
    success: function (arr) {
        console.log(arr);
        controller.handleGenderChange(arr);
    }//回调
});