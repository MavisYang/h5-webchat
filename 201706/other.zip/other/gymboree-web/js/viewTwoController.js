/**
 * Created by jiayi.hu on 3/16/17.
 */
var controller = {
    init: function () {
        //cookie中取值
        document.getElementById('phone').oninput = this.handleCode;
        document.getElementById('sendVerifyCode').onclick = this.sendCode;
        document.getElementById('submit').onclick = this.submit;
        document.getElementById('phone').onfocus = this.highlight;
        document.getElementById('email').onfocus = this.highlight;
        document.getElementById('phone').onblur = this.removeHighlight;
        document.getElementById('email').onblur = this.removeHighlight;
        document.getElementById('referralCode').onfocus = this.highlight;
        document.getElementById('referralCode').onblur = this.removeHighlight;
        if($("#phone").val().length = 11){
            $("#sendVerifyCode").addClass("sendHighlight");
        }else {
            $("#sendVerifyCode").removeClass("sendHighlight");
        }
        eventFunctions.pullCookie();
    },
    handleRelation: function (arr) {
        if (arr.length == 1) {
            $("input[id=babyRelation]").val(arr[0].value).attr("name",arr[0].id+arr[0].value);
        }
    },
    handleCode: function () {
        if (this.value.length < 11) {
            $("#sendVerifyCode").removeClass("sendHighlight");
        } else if (this.value.length > 11) {
            this.value = this.value.substr(0, 11);
        } else {
            $("#sendVerifyCode").addClass("sendHighlight");
        }
    },
    sendCode: function () {
        var teleInput = $("input[id=" + "phone" + "]");
        if (!(/^1[34578]\d{9}$/.test(teleInput.val()))) {
            alert("手机号错误");
            teleInput.focus();
        } else {
            document.getElementById('phoneCode').onfocus = controller.highlight;
            document.getElementById('phoneCode').onblur = controller.removeHighlight;
            $("input[id=phoneCode]").prop("readonly", false);
            //同步请求
            dataModule.postPhoneNumber(teleInput.val());
        }
    },
    highlight: function () {
        //点击空白区域模态框消失
        $(this).addClass("highlight");
    },
    removeHighlight: function () {
        $(this).removeClass("highlight");
    },
    SelHighlight: function () {
        //点击空白区域模态框消失
        $(this).next().addClass("highlight");
    },
    SelRemoveHighlight: function () {
        $(this).next().removeClass("highlight");
    },
    submit: function () {
        var self = $(this);
        var comment = new Array();
        var allInput = document.querySelectorAll("input[type=text]");
        var emailInput = $("input[id=email]");
        var codeInput = $("input[id=referralCode]");
        comment.push(allInput[0].value, allInput[1].value, allInput[2].value);
        if (comment.indexOf("") != -1) {
            alert("完善信息");
            return;
        }
        if (!(/^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/.test(emailInput.val())) && !(emailInput.val() == "")) {
            alert("请输入有效的邮箱");
            emailInput.focus();
            return;
        }
        if(!(/^[0-9]{11}$/.test(codeInput.val()))&& !(codeInput.val() == "")){
            alert("请输入正确邀请码格式");
            codeInput.focus();
            return;
        }
        self.attr("disabled",true);
        var subReply = dataModule.postUserInfo(eventFunctions.pushCookie());
        console.log(subReply)
        if (subReply.status == 200) {
            window.location.href = "QRcode.html?data=" + subReply.data.robotId;
        } else if (subReply.status == -1) {
            self.removeAttr("disabled");
            alert("匹配失败");
        } else if(subReply.status == -2){
            self.removeAttr("disabled");
            alert("验证码不正确");
        }else {
            alert("提交失败,请刷新重试")
        }
    }
}
var eventFunctions = {
    //发送计时器
    sendVerifyCode: function () {
        //发送验证码请求
        var times = 60;
        var timer = null;
        var sendVerifyCode = $("#sendVerifyCode");
        timer = setInterval(function () {
            times--;
            if (times <= 0) {
                sendVerifyCode.val("发送验证码");
                sendVerifyCode.attr("disabled", false);
                sendVerifyCode.css({"background": "#F09617", "border": "1px solid #F09617"});
                clearInterval(timer);
            }
            else {
                sendVerifyCode.val("剩余" + times + "s");
                sendVerifyCode.attr("disabled", true);
                sendVerifyCode.css({"background": "#E5DFD9", "border": "1px solid #E5DFD9"});
            }
        }, 1000);
    },
    pullCookie: function () {
        if($.cookie("data_submit") == undefined){
            return;
        }
        var currentData = JSON.parse($.cookie("data_submit"))
        console.log(currentData)
        for (var i in currentData){
            if(i == "babyRelation"){
                $("input[id="+i+"]").val(currentData[i].substr(1)).attr("name",currentData[i])
            }else {
                $("input[id=" + i + "]").val(currentData[i])
            }
        }
    },
    pushCookie: function () {
        var cookieData = new Object();
        var sendData = new Object();
        var allInput = document.querySelectorAll("input[type=text]");
        console.log(allInput)
        $.each(allInput,function (k,v) {
            if(v.id=="babyRelation"){
                sendData[v.id] = v.name.substr(0,1)
                cookieData[v.id] = v.name
            }else {
                sendData[v.id] = v.value
                cookieData[v.id] = v.value
            }
        })
        $.cookie("data_submit", JSON.stringify(cookieData) , {"expires": 1});
        var nextData = JSON.parse($.cookie("data_next"));
        for (var k in nextData){
            console.log(k)
            if(k=="babyGender"){
                sendData[k] = nextData[k].substr(0,1)
            }else {
                sendData[k] = nextData[k]
            }
        }
        console.log(cookieData)
        return sendData;
    }
}