/**
 * Created by jiayi.hu on 3/20/17.
 */
new MultiPicker({
    input: 'babyRelation',//点击触发插件的input框的id
    container: 'relationContainer',//插件插入的容器id
    jsonData:[{"id":0,"value": "母亲"},{"id":1,"value": "父亲"},{"id":2,"value":"祖辈"},{"id":3,"value":"其他"}],
    success: function (arr) {
        console.log(arr);
        controller.handleRelation(arr);
    }//回调
});