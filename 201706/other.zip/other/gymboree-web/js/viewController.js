/**
 * Created by jiayi.hu on 3/16/17.
 */
var controller = {
    init: function () {
        document.getElementById('next').onclick = this.submit;
        //选中框高亮
        document.getElementById('babyName').onfocus = this.highlight;
        document.getElementById('babyName').onblur = this.removeHighlight;
        eventFunctions.pullCookie();
    },
    handleGenderChange: function (arr) {
        if (arr.length == 1) {
            $("input[id = " + "babyGender" + "]").val(arr[0].value).attr("name",arr[0].id+arr[0].value);
        }
    },
    handleBirChange: function (arr) {
        if (arr.length == 3) {
            $("input[id = " + "babyBirth" + "]").val(arr[0] + "-" + arr[1] + "-" + arr[2]);
        }
    },
    highlight: function () {
        //点击空白区域模态框消失
        $(this).addClass("highlight");
    },
    removeHighlight: function () {
        $(this).removeClass("highlight");
    },
    SelHighlight: function () {
        //点击空白区域模态框消失
        $(this).next().addClass("highlight");
    },
    SelRemoveHighlight: function () {
        $(this).next().removeClass("highlight");
    },
    submit: function () {
        var comment = new Array();
        $.each(document.querySelectorAll("input[type=text]"), function (k, v) {
            comment.push(v.value);
        })
        if (comment.indexOf("") != -1) {
            alert("完善信息");
            return;
        }
        eventFunctions.pushCookie();
        window.location.href = "apply.html";
    }
}
var eventFunctions = {
    pullCookie: function () {
        console.log($.cookie("data_next"))
        if($.cookie("data_next")==undefined){
            return;
        }
        var currentData = JSON.parse($.cookie("data_next"));
        console.log(currentData)
        for (var k in currentData){
            if(!(k=="centre")){
                if(k == "babyGender"){
                    $("input[id=" + k + "]").val(currentData[k].substr(1)).attr("name",currentData[k])
                }else {
                    $("input[id=" + k + "]").val(currentData[k])
                }
            }
        }
    },
    pushCookie: function () {
        var cookieData = new Object();
        var allInput = document.querySelectorAll("input[type=text]");
        $.each(allInput,function (k,v) {
            if(v.id=="babyGender"){
                cookieData[v.id] = v.name;
            }else {
                cookieData[v.id] = v.value;
            }
        })
        $.cookie("data_next", JSON.stringify(cookieData), {"expires": 1});
        console.log(cookieData)
    }
}