/**
 * Created by jiayi.hu on 3/22/17.
 */
var hosArr = new Array();
var infoData = new Object();
var dataModule = {
    url: {
        hosByCity: "http://wyeth.gemii.cc/HelperManage/enter/getHosByCity",
        userInfo: "http://wx.gemii.cc/wx/userinfo/getUserInfo",
        member: "http://wyeth.gemii.cc/HelperManage/enter/huggies/member",
        savepoint:"http://wyeth.gemii.cc/HelperManage/savepoint"
    },
    postSave: function (Data) {
        var url = this.url.savepoint;
        $.ajax({
            url:url,
            data:Data,
            type:"POST",
            success: function (res) {
                //success
            },
            error: function () {
                //error
            }
        })
    },
    postMemberInfo: function (Data,e) {
        var url = this.url.member;
        $.ajax({
            type: "POST",
            data: Data,
            url: url,
            dataType: "json",
            cache: false,
            beforeSend: function () {
                $(e).val("提交中");
                $(e).attr("disabled",true);
            },
            success: function (json) {
                switch (eval(json).status){
                    case 200:
                        console.log(eval(json))
                        var monitorSuc = new Object();
                        monitorSuc.content = infoData.data.fwOpenid+":"+infoData.data.nickname+":"+Data.phone;
                        monitorSuc.pointName = "用户匹配";
                        monitorSuc.pageName = "展示二维码页面";
                        monitorSuc.userKey = infoData.data.fwOpenid;
                        dataModule.postSave(monitorSuc);
                        window.location.href = "QRcode.html?QRcodeUrl="+eval(json).data.robotID;
                        break;
                    case -1:
                        var monitorFail = new Object();
                        monitorFail.content = infoData.data.fwOpenid+":"+infoData.data.nickname+":"+Data.phone;
                        monitorFail.pointName = "用户未匹配";
                        monitorFail.pageName = "不展示二维码页面";
                        monitorFail.userKey = infoData.data.fwOpenid;
                        dataModule.postSave(monitorFail);
                        window.location.href = "sorry.html";
                        break;
                    case -2:
                        alert("达到入群人数限制")
                        break;
                    case -3:
                        alert("重复申请")
                        break;
                    case -4:
                        alert("没有找到合适的群")
                        break;
                    case 500:
                        alert("提交出错,请重试!")
                }
            },
            error: function () {
                alert("提交出错,请重试!")
            },
            complete:function () {
                $(e).val("提交");
                $(e).removeAttr("disabled");
            }

        })
    },
    getUserInfo: function (code) {
        var url = this.url.userInfo + "?code=" + code;
        $.ajax({
            type: "GET",
            url: url,
            dataType: "json",
            cache: false,
            success: function (json) {
                infoData = eval(json);
                // infoData = {
                //     "status": 200,
                //     "msg": "OK",
                //     "data": {
                //         "fwOpenid": "oNPcuvwLESJ-zxPmiUWvfrqqduz0",
                //         "nickname": "nickname",
                //         "headimgurl": "headimgurl",
                //         "province":"中国"
                //     }
                // }
                var monitor = new Object();
                monitor.content = infoData.data.fwOpenid+":"+infoData.data.nickname;
                monitor.pointName = "点击消息";
                monitor.pageName = "用户信息填写页面";
                monitor.userKey = infoData.data.fwOpenid;
                dataModule.postSave(monitor);
            },
            error: function () {

            }
        })
    },
    getHosByCity: function (Data) {
        var url = this.url.hosByCity + "?city=" + Data;
        $.ajax({
            type: "POST",
            url: url,
            dataType: "json",
            cache: false,
            success: function (json) {
                console.log(eval(json));
                hosArr.splice(0, hosArr.length);
                if (!(eval(json).data.length == 0)) {
                    for (var id in eval(json).data) {
                        hosArr.push({"value": eval(json).data[id]})
                    }
                    hosArr.push({"value":"其他"})
                } else {
                    hosArr.push({"value": "其他"})
                }
                new MultiPicker({
                    input: 'hospitalChange',//点击触发插件的input框的id
                    container: 'hospitalContainer',//插件插入的容器id
                    jsonData: hosArr,
                    success: function (arr) {
                        controller.handleHospitalChange(arr);
                    }//回调
                });
            },
            error: function () {
            }
        })
    }
}