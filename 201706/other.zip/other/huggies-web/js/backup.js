var $city = [
    {
        "value": "北京",
        "id": 0
    },
    {
        "value": "广东",
        "child": [
            {
                "value": "广州",
               
                "id": 0
            },
            {
                "value": "深圳",
               
                "id": 0
            },
            {
                "value": "珠海",
               
                "id": 0
            },
            {
                "value": "汕头",
               
                "id": 0
            },
            {
                "value": "韶关",
               
                "id": 0
            },
            {
                "value": "佛山",
               
                "id": 0
            },
            {
                "value": "江门",
               
                "id": 0
            },
            {
                "value": "湛江",
               
                "id": 0
            },
            {
                "value": "茂名",
               
                "id": 0
            },
            {
                "value": "肇庆",
               
                "id": 0
            },
            {
                "value": "惠州",
               
                "id": 0
            },
            {
                "value": "梅州",
               
                "id": 0
            },
            {
                "value": "汕尾",
               
                "id": 0
            },
            {
                "value": "河源",
               
                "id": 0
            },
            {
                "value": "阳江",
               
                "id": 0
            },
            {
                "value": "清远",
               
                "id": 0
            },
            {
                "value": "东莞",
                "id": 0
            },
            {
                "value": "中山",
                "id": 0
            },
            {
                "value": "潮州",
               
                "id": 0
            },
            {
                "value": "揭阳",
               
                "id": 0
            },
            {
                "value": "云浮",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "上海",
        "id": 0
    },
    {
        "value": "天津",
        "id": 0
    },
    {
        "value": "重庆",
        "id": 0
    },
    {
        "value": "辽宁",
        "child": [
            {
                "value": "沈阳",
               
                "id": 0
            },
            {
                "value": "大连",
               
                "id": 0
            },
            {
                "value": "鞍山",
               
                "id": 0
            },
            {
                "value": "抚顺",
               
                "id": 0
            },
            {
                "value": "本溪",
               
                "id": 0
            },
            {
                "value": "丹东",
               
                "id": 0
            },
            {
                "value": "锦州",
               
                "id": 0
            },
            {
                "value": "营口",
               
                "id": 0
            },
            {
                "value": "阜新",
               
                "id": 0
            },
            {
                "value": "辽阳",
               
                "id": 0
            },
            {
                "value": "盘锦",
               
                "id": 0
            },
            {
                "value": "铁岭",
               
                "id": 0
            },
            {
                "value": "朝阳",
               
                "id": 0
            },
            {
                "value": "葫芦岛",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "江苏",
        "child": [
            {
                "value": "南京",
               
                "id": 0
            },
            {
                "value": "苏州",
               
                "id": 0
            },
            {
                "value": "无锡",
               
                "id": 0
            },
            {
                "value": "常州",
               
                "id": 0
            },
            {
                "value": "镇江",
               
                "id": 0
            },
            {
                "value": "南通",
               
                "id": 0
            },
            {
                "value": "泰州",
               
                "id": 0
            },
            {
                "value": "扬州",
               
                "id": 0
            },
            {
                "value": "盐城",
               
                "id": 0
            },
            {
                "value": "连云港",
               
                "id": 0
            },
            {
                "value": "徐州",
               
                "id": 0
            },
            {
                "value": "淮安",
               
                "id": 0
            },
            {
                "value": "宿迁",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "湖北",
        "child": [
            {
                "value": "武汉",
               
                "id": 0
            },
            {
                "value": "黄石",
               
                "id": 0
            },
            {
                "value": "十堰",
               
                "id": 0
            },
            {
                "value": "荆州",
               
                "id": 0
            },
            {
                "value": "宜昌",
               
                "id": 0
            },
            {
                "value": "襄樊",
               
                "id": 0
            },
            {
                "value": "鄂州",
               
                "id": 0
            },
            {
                "value": "荆门",
               
                "id": 0
            },
            {
                "value": "孝感",
               
                "id": 0
            },
            {
                "value": "黄冈",
               
                "id": 0
            },
            {
                "value": "咸宁",
               
                "id": 0
            },
            {
                "value": "随州",
               
                "id": 0
            },
            {
                "value": "恩施土家族苗族自治州",
               
                "id": 0
            },
            {
                "value": "仙桃",
                "id": 0
            },
            {
                "value": "天门",
                "id": 0
            },
            {
                "value": "潜江",
                "id": 0
            },
            {
                "value": "神农架林区",
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "四川",
        "child": [
            {
                "value": "成都",
               
                "id": 0
            },
            {
                "value": "自贡",
               
                "id": 0
            },
            {
                "value": "攀枝花",
               
                "id": 0
            },
            {
                "value": "泸州",
               
                "id": 0
            },
            {
                "value": "德阳",
               
                "id": 0
            },
            {
                "value": "绵阳",
               
                "id": 0
            },
            {
                "value": "广元",
               
                "id": 0
            },
            {
                "value": "遂宁",
               
                "id": 0
            },
            {
                "value": "内江",
               
                "id": 0
            },
            {
                "value": "乐山",
               
                "id": 0
            },
            {
                "value": "南充",
               
                "id": 0
            },
            {
                "value": "眉山",
               
                "id": 0
            },
            {
                "value": "宜宾",
               
                "id": 0
            },
            {
                "value": "广安",
               
                "id": 0
            },
            {
                "value": "达州",
               
                "id": 0
            },
            {
                "value": "雅安",
               
                "id": 0
            },
            {
                "value": "巴中",
               
                "id": 0
            },
            {
                "value": "资阳",
               
                "id": 0
            },
            {
                "value": "阿坝藏族羌族自治州",
               
                "id": 0
            },
            {
                "value": "甘孜藏族自治州",
               
                "id": 0
            },
            {
                "value": "凉山彝族自治州",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "陕西",
        "child": [
            {
                "value": "西安",
               
                "id": 0
            },
            {
                "value": "铜川",
               
                "id": 0
            },
            {
                "value": "宝鸡",
               
                "id": 0
            },
            {
                "value": "咸阳",
               
                "id": 0
            },
            {
                "value": "渭南",
               
                "id": 0
            },
            {
                "value": "延安",
               
                "id": 0
            },
            {
                "value": "汉中",
               
                "id": 0
            },
            {
                "value": "榆林",
               
                "id": 0
            },
            {
                "value": "安康",
               
                "id": 0
            },
            {
                "value": "商洛",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "河北",
        "child": [
            {
                "value": "石家庄",
               
                "id": 0
            },
            {
                "value": "唐山",
               
                "id": 0
            },
            {
                "value": "秦皇岛",
               
                "id": 0
            },
            {
                "value": "邯郸",
               
                "id": 0
            },
            {
                "value": "邢台",
               
                "id": 0
            },
            {
                "value": "保定",
               
                "id": 0
            },
            {
                "value": "张家口",
               
                "id": 0
            },
            {
                "value": "承德",
               
                "id": 0
            },
            {
                "value": "沧州",
               
                "id": 0
            },
            {
                "value": "廊坊",
               
                "id": 0
            },
            {
                "value": "衡水",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "山西",
        "child": [
            {
                "value": "太原",
               
                "id": 0
            },
            {
                "value": "大同",
               
                "id": 0
            },
            {
                "value": "阳泉",
               
                "id": 0
            },
            {
                "value": "长治",
               
                "id": 0
            },
            {
                "value": "晋城",
               
                "id": 0
            },
            {
                "value": "朔州",
               
                "id": 0
            },
            {
                "value": "晋中",
               
                "id": 0
            },
            {
                "value": "运城",
               
                "id": 0
            },
            {
                "value": "忻州",
               
                "id": 0
            },
            {
                "value": "临汾",
               
                "id": 0
            },
            {
                "value": "吕梁",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "河南",
        "child": [
            {
                "value": "郑州",
               
                "id": 0
            },
            {
                "value": "开封",
               
                "id": 0
            },
            {
                "value": "洛阳",
               
                "id": 0
            },
            {
                "value": "平顶山",
               
                "id": 0
            },
            {
                "value": "安阳",
               
                "id": 0
            },
            {
                "value": "鹤壁",
               
                "id": 0
            },
            {
                "value": "新乡",
               
                "id": 0
            },
            {
                "value": "焦作",
               
                "id": 0
            },
            {
                "value": "濮阳",
               
                "id": 0
            },
            {
                "value": "许昌",
               
                "id": 0
            },
            {
                "value": "漯河",
               
                "id": 0
            },
            {
                "value": "三门峡",
               
                "id": 0
            },
            {
                "value": "南阳",
               
                "id": 0
            },
            {
                "value": "商丘",
               
                "id": 0
            },
            {
                "value": "信阳",
               
                "id": 0
            },
            {
                "value": "周口",
               
                "id": 0
            },
            {
                "value": "驻马店",
               
                "id": 0
            },
            {
                "value": "焦作",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "吉林",
        "child": [
            {
                "value": "长春",
               
                "id": 0
            },
            {
                "value": "吉林",
               
                "id": 0
            },
            {
                "value": "四平",
               
                "id": 0
            },
            {
                "value": "辽源",
               
                "id": 0
            },
            {
                "value": "通化",
               
                "id": 0
            },
            {
                "value": "白山",
               
                "id": 0
            },
            {
                "value": "松原",
               
                "id": 0
            },
            {
                "value": "白城",
               
                "id": 0
            },
            {
                "value": "延边朝鲜族自治州",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "黑龙江",
        "child": [
            {
                "value": "哈尔滨",
               
                "id": 0
            },
            {
                "value": "齐齐哈尔",
               
                "id": 0
            },
            {
                "value": "鹤岗",
               
                "id": 0
            },
            {
                "value": "双鸭山",
               
                "id": 0
            },
            {
                "value": "鸡西",
               
                "id": 0
            },
            {
                "value": "大庆",
               
                "id": 0
            },
            {
                "value": "伊春",
               
                "id": 0
            },
            {
                "value": "牡丹江",
               
                "id": 0
            },
            {
                "value": "佳木斯",
               
                "id": 0
            },
            {
                "value": "七台河",
               
                "id": 0
            },
            {
                "value": "黑河",
               
                "id": 0
            },
            {
                "value": "绥化",
               
                "id": 0
            },
            {
                "value": "大兴安岭地区",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "内蒙古",
        "child": [
            {
                "value": "呼和浩特",
               
                "id": 0
            },
            {
                "value": "包头",
               
                "id": 0
            },
            {
                "value": "乌海",
               
                "id": 0
            },
            {
                "value": "赤峰",
               
                "id": 0
            },
            {
                "value": "通辽",
               
                "id": 0
            },
            {
                "value": "鄂尔多斯",
               
                "id": 0
            },
            {
                "value": "呼伦贝尔",
               
                "id": 0
            },
            {
                "value": "巴彦淖尔",
               
                "id": 0
            },
            {
                "value": "乌兰察布",
               
                "id": 0
            },
            {
                "value": "锡林郭勒盟",
               
                "id": 0
            },
            {
                "value": "兴安盟",
               
                "id": 0
            },
            {
                "value": "阿拉善盟",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "山东",
        "child": [
            {
                "value": "济南",
               
                "id": 0
            },
            {
                "value": "青岛",
               
                "id": 0
            },
            {
                "value": "淄博",
               
                "id": 0
            },
            {
                "value": "枣庄",
               
                "id": 0
            },
            {
                "value": "东营",
               
                "id": 0
            },
            {
                "value": "烟台",
               
                "id": 0
            },
            {
                "value": "潍坊",
               
                "id": 0
            },
            {
                "value": "济宁",
               
                "id": 0
            },
            {
                "value": "泰安",
               
                "id": 0
            },
            {
                "value": "威海",
               
                "id": 0
            },
            {
                "value": "日照",
               
                "id": 0
            },
            {
                "value": "莱芜",
               
                "id": 0
            },
            {
                "value": "临沂",
               
                "id": 0
            },
            {
                "value": "德州",
               
                "id": 0
            },
            {
                "value": "聊城",
               
                "id": 0
            },
            {
                "value": "滨州",
               
                "id": 0
            },
            {
                "value": "菏泽",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "安徽",
        "child": [
            {
                "value": "合肥",
               
                "id": 0
            },
            {
                "value": "芜湖",
               
                "id": 0
            },
            {
                "value": "蚌埠",
               
                "id": 0
            },
            {
                "value": "淮南",
               
                "id": 0
            },
            {
                "value": "马鞍山",
               
                "id": 0
            },
            {
                "value": "淮北",
               
                "id": 0
            },
            {
                "value": "铜陵",
               
                "id": 0
            },
            {
                "value": "安庆",
               
                "id": 0
            },
            {
                "value": "黄山",
               
                "id": 0
            },
            {
                "value": "滁州",
               
                "id": 0
            },
            {
                "value": "阜阳",
               
                "id": 0
            },
            {
                "value": "宿州",
               
                "id": 0
            },
            {
                "value": "巢湖",
               
                "id": 0
            },
            {
                "value": "六安",
               
                "id": 0
            },
            {
                "value": "亳州",
               
                "id": 0
            },
            {
                "value": "池州",
               
                "id": 0
            },
            {
                "value": "宣城",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "浙江",
        "child": [
            {
                "value": "杭州",
               
                "id": 0
            },
            {
                "value": "宁波",
               
                "id": 0
            },
            {
                "value": "温州",
               
                "id": 0
            },
            {
                "value": "嘉兴",
               
                "id": 0
            },
            {
                "value": "湖州",
               
                "id": 0
            },
            {
                "value": "绍兴",
               
                "id": 0
            },
            {
                "value": "金华",
               
                "id": 0
            },
            {
                "value": "衢州",
               
                "id": 0
            },
            {
                "value": "舟山",
               
                "id": 0
            },
            {
                "value": "台州",
               
                "id": 0
            },
            {
                "value": "丽水",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "福建",
        "child": [
            {
                "value": "福州",
               
                "id": 0
            },
            {
                "value": "厦门",
               
                "id": 0
            },
            {
                "value": "莆田",
               
                "id": 0
            },
            {
                "value": "三明",
               
                "id": 0
            },
            {
                "value": "泉州",
               
                "id": 0
            },
            {
                "value": "漳州",
               
                "id": 0
            },
            {
                "value": "南平",
               
                "id": 0
            },
            {
                "value": "龙岩",
               
                "id": 0
            },
            {
                "value": "宁德",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "湖南",
        "child": [
            {
                "value": "长沙",
               
                "id": 0
            },
            {
                "value": "株洲",
               
                "id": 0
            },
            {
                "value": "湘潭",
               
                "id": 0
            },
            {
                "value": "衡阳",
               
                "id": 0
            },
            {
                "value": "邵阳",
               
                "id": 0
            },
            {
                "value": "岳阳",
               
                "id": 0
            },
            {
                "value": "常德",
               
                "id": 0
            },
            {
                "value": "张家界",
               
                "id": 0
            },
            {
                "value": "益阳",
               
                "id": 0
            },
            {
                "value": "郴州",
               
                "id": 0
            },
            {
                "value": "永州",
               
                "id": 0
            },
            {
                "value": "怀化",
               
                "id": 0
            },
            {
                "value": "娄底",
               
                "id": 0
            },
            {
                "value": "湘西土家族苗族自治州",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "广西",
        "child": [
            {
                "value": "南宁",
               
                "id": 0
            },
            {
                "value": "柳州",
               
                "id": 0
            },
            {
                "value": "桂林",
               
                "id": 0
            },
            {
                "value": "梧州",
               
                "id": 0
            },
            {
                "value": "北海",
               
                "id": 0
            },
            {
                "value": "防城港",
               
                "id": 0
            },
            {
                "value": "钦州",
               
                "id": 0
            },
            {
                "value": "贵港",
               
                "id": 0
            },
            {
                "value": "玉林",
               
                "id": 0
            },
            {
                "value": "百色",
               
                "id": 0
            },
            {
                "value": "贺州",
               
                "id": 0
            },
            {
                "value": "河池",
               
                "id": 0
            },
            {
                "value": "来宾",
               
                "id": 0
            },
            {
                "value": "崇左",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "江西",
        "child": [
            {
                "value": "南昌",
               
                "id": 0
            },
            {
                "value": "景德镇",
               
                "id": 0
            },
            {
                "value": "萍乡",
               
                "id": 0
            },
            {
                "value": "九江",
               
                "id": 0
            },
            {
                "value": "新余",
               
                "id": 0
            },
            {
                "value": "鹰潭",
               
                "id": 0
            },
            {
                "value": "赣州",
               
                "id": 0
            },
            {
                "value": "吉安",
               
                "id": 0
            },
            {
                "value": "宜春",
               
                "id": 0
            },
            {
                "value": "抚州",
               
                "id": 0
            },
            {
                "value": "上饶",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "贵州",
        "child": [
            {
                "value": "贵阳",
               
                "id": 0
            },
            {
                "value": "六盘水",
               
                "id": 0
            },
            {
                "value": "遵义",
               
                "id": 0
            },
            {
                "value": "安顺",
               
                "id": 0
            },
            {
                "value": "铜仁地区",
               
                "id": 0
            },
            {
                "value": "毕节地区",
               
                "id": 0
            },
            {
                "value": "黔西南布依族苗族自治州",
               
                "id": 0
            },
            {
                "value": "黔东南苗族侗族自治州",
               
                "id": 0
            },
            {
                "value": "黔南布依族苗族自治州",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "云南",
        "child": [
            {
                "value": "昆明",
               
                "id": 0
            },
            {
                "value": "曲靖",
               
                "id": 0
            },
            {
                "value": "玉溪",
               
                "id": 0
            },
            {
                "value": "保山",
               
                "id": 0
            },
            {
                "value": "昭通",
               
                "id": 0
            },
            {
                "value": "丽江",
               
                "id": 0
            },
            {
                "value": "普洱",
               
                "id": 0
            },
            {
                "value": "临沧",
               
                "id": 0
            },
            {
                "value": "德宏傣族景颇族自治州",
               
                "id": 0
            },
            {
                "value": "怒江傈僳族自治州",
               
                "id": 0
            },
            {
                "value": "迪庆藏族自治州",
               
                "id": 0
            },
            {
                "value": "大理白族自治州",
               
                "id": 0
            },
            {
                "value": "楚雄彝族自治州",
               
                "id": 0
            },
            {
                "value": "红河哈尼族彝族自治州",
               
                "id": 0
            },
            {
                "value": "文山壮族苗族自治州",
               
                "id": 0
            },
            {
                "value": "西双版纳傣族自治州",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "西藏",
        "child": [
            {
                "value": "拉萨",
               
                "id": 0
            },
            {
                "value": "那曲地区",
               
                "id": 0
            },
            {
                "value": "昌都地区",
               
                "id": 0
            },
            {
                "value": "林芝地区",
               
                "id": 0
            },
            {
                "value": "山南地区",
               
                "id": 0
            },
            {
                "value": "日喀则地区",
               
                "id": 0
            },
            {
                "value": "阿里地区",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "海南省",
        "child": [
            {
                "value": "海口",
               
                "id": 0
            },
            {
                "value": "三亚",
               
                "id": 0
            },
            {
                "value": "五指山",
                "id": 0
            },
            {
                "value": "琼海",
                "id": 0
            },
            {
                "value": "儋州",
                "id": 0
            },
            {
                "value": "文昌",
                "id": 0
            },
            {
                "value": "万宁",
                "id": 0
            },
            {
                "value": "东方",
                "id": 0
            },
            {
                "value": "澄迈县",
                "id": 0
            },
            {
                "value": "定安县",
                "id": 0
            },
            {
                "value": "屯昌县",
                "id": 0
            },
            {
                "value": "临高县",
                "id": 0
            },
            {
                "value": "白沙黎族自治县",
                "id": 0
            },
            {
                "value": "昌江黎族自治县",
                "id": 0
            },
            {
                "value": "乐东黎族自治县",
                "id": 0
            },
            {
                "value": "陵水黎族自治县",
                "id": 0
            },
            {
                "value": "保亭黎族苗族自治县",
                "id": 0
            },
            {
                "value": "琼中黎族苗族自治县",
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "甘肃",
        "child": [
            {
                "value": "兰州",
               
                "id": 0
            },
            {
                "value": "嘉峪关",
               
                "id": 0
            },
            {
                "value": "金昌",
               
                "id": 0
            },
            {
                "value": "白银",
               
                "id": 0
            },
            {
                "value": "天水",
               
                "id": 0
            },
            {
                "value": "武威",
               
                "id": 0
            },
            {
                "value": "酒泉",
               
                "id": 0
            },
            {
                "value": "张掖",
               
                "id": 0
            },
            {
                "value": "庆阳",
               
                "id": 0
            },
            {
                "value": "平凉",
               
                "id": 0
            },
            {
                "value": "定西",
               
                "id": 0
            },
            {
                "value": "陇南",
               
                "id": 0
            },
            {
                "value": "临夏回族自治州",
               
                "id": 0
            },
            {
                "value": "甘南藏族自治州",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "宁夏",
        "child": [
            {
                "value": "银川",
               
                "id": 0
            },
            {
                "value": "石嘴山",
               
                "id": 0
            },
            {
                "value": "吴忠",
               
                "id": 0
            },
            {
                "value": "固原",
               
                "id": 0
            },
            {
                "value": "中卫",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "青海",
        "child": [
            {
                "value": "西宁",
               
                "id": 0
            },
            {
                "value": "海东地区",
               
                "id": 0
            },
            {
                "value": "海北藏族自治州",
               
                "id": 0
            },
            {
                "value": "海南藏族自治州",
               
                "id": 0
            },
            {
                "value": "黄南藏族自治州",
               
                "id": 0
            },
            {
                "value": "果洛藏族自治州",
               
                "id": 0
            },
            {
                "value": "玉树藏族自治州",
               
                "id": 0
            },
            {
                "value": "海西蒙古族藏族自治州",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "新疆",
        "child": [
            {
                "value": "乌鲁木齐",
               
                "id": 0
            },
            {
                "value": "克拉玛依",
               
                "id": 0
            },
            {
                "value": "吐鲁番地区",
               
                "id": 0
            },
            {
                "value": "哈密地区",
               
                "id": 0
            },
            {
                "value": "和田地区",
               
                "id": 0
            },
            {
                "value": "阿克苏地区",
               
                "id": 0
            },
            {
                "value": "喀什地区",
               
                "id": 0
            },
            {
                "value": "克孜勒苏柯尔克孜自治州",
               
                "id": 0
            },
            {
                "value": "巴音郭楞蒙古自治州",
               
                "id": 0
            },
            {
                "value": "昌吉回族自治州",
               
                "id": 0
            },
            {
                "value": "博尔塔拉蒙古自治州",
               
                "id": 0
            },
            {
                "value": "石河子",
                "id": 0
            },
            {
                "value": "阿拉尔",
                "id": 0
            },
            {
                "value": "图木舒克",
                "id": 0
            },
            {
                "value": "五家渠",
                "id": 0
            },
            {
                "value": "伊犁哈萨克自治州",
               
                "id": 0
            },
            {
                "value": "其他"
            }
        ],
        "id": 1
    },
    {
        "value": "香港",
        "id": 0
    },
    {
        "value": "澳门",
        "id": 0
    },
    {
        "value": "台湾",
        "id": 0
    },
    {
        "value": "其他"
    }
]