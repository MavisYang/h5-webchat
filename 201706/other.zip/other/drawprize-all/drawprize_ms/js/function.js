/**
 * Created by walter on 10/26/16.
 */

function dataLoad(filename) {
    var arraydata;
    $.ajax({
        type: "GET",
        url: filename,
        dataType: "json",
        async: false,
        success: function (json) {
            arraydata = eval(json)
        }
    });
    return arraydata;
}
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)
        return (r[2]);
    return null;
}
function checkMobile(str) {
    var re = /^1\d{10}$/;
    if (re.test(str)) {
        return true;
    } else {
        alert("您输入的电话号码格式不正确!");
        return false;
    }
}

function prizeLeve(state) {
    $(".wrap").fadeIn();
    const leveOne = "<div class='inner'>" +
        "<div class='LeveOneTag'></div>" +
        "<div class='linkLine'><p>点击以下链接完成寄送信息填写</p>"+
        "<a href='https://www.wjx.top/jq/16638389.aspx'>https://www.wjx.top/jq/16638389.aspx</a>"+
        "</div>"+
        "</div>" +
        "<div class='cancelButt'></div>"; 
    const leveTwo = "<div class='inner'>" +
        "<div class='leveThree'><div class='threeTip'><img src='./images/awards1.jpg' class='giftPic'/><p class='giftName'>御信堂洗衣液</p></div></div>" +
        "<div class='linkLine'><p>点击以下链接完成寄送信息填写</p>"+
        "<a href='https://www.wjx.top/jq/16638389.aspx'>https://www.wjx.top/jq/16638389.aspx</a>"+
        "</div>"+
        "</div>" +
        "<div class='cancelButt'></div>";    
    const leveThree = "<div class='inner'>" +
        "<div class='LeveTwoTag'></div>" +
        "</div>" +
        "<div class='cancelButt'></div>";

    switch (state) {
        case 1:
            $(".wrap").html("");
            $(".wrap").html(leveOne);//微波碗勺套装
            break;
        case 2:
            $(".wrap").html("");
            $(".wrap").html(leveTwo);//洗衣液
            break;
        case 3:
            $(".wrap").html("");
            $(".wrap").html(leveThree);
            break;
    }

    $(".cancelButt").get(0).addEventListener("touchstart", function (e) {
        e.preventDefault();
        $(".wrap").fadeOut();
    })
}

function QRcode() {
    $(".QRcode_wrap").fadeIn(0);
    $(".QRcode_wrap").html("");
    $(".QRcode_wrap").html("<div class='QRcode_inner'>" +
        "<img class='QRcode' src='images/QR-code.jpeg' style='width: 100%;padding-top: 220px;'>" +
        "</div>" +
        "<div class='QRcode_cancelButt'></div>");
    $(".QRcode_cancelButt").get(0).addEventListener("touchstart", function (e) {
        e.preventDefault();
        $(".QRcode_wrap").fadeOut(0);
    })
}