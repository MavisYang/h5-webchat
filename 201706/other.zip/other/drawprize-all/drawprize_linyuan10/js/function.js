/**
 * Created by walter on 10/26/16.
 */

function dataLoad(filename) {
    var arraydata;
    $.ajax({
        type: "GET",
        url: filename,
        dataType: "json",
        async: false,
        success: function(json) {
            arraydata = eval(json)
        }
    });
    return arraydata;
}

function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)
        return (r[2]);
    return null;
}

function checkMobile(str) {
    var re = /^1\d{10}$/;
    if (re.test(str)) {
        return true;
    } else {
        alert("您输入的电话号码格式不正确!");
        return false;
    }
}

function prizeLeve(state) {
    $(".wrap").fadeIn();
    var leveOne = "<div class='inner'>" +
        "<div class='innerHeader'>恭喜宝妈获得<br>启韵孕产妇配方调制乳粉</div>" +
        "<div class='LeveOneTag'></div>" +
        "<div class='innerFooter'>我们将在7个工作日内安排发货,<br>请注意查收!<br>关注栗子妈妈公众号<br>更多福利等着您~</div>" +
        "</div>" +
        "<div class='cancelButt'></div>";
    var leveTwo = "<div class='inner'>" +
        "<div class='innerHeader'>真遗憾<br>您没有中奖</div>" +
        "<div class='LeveTwoTag'></div>" +
        "<div class='innerFooter'>感谢宝妈对活动的支持!<br>关注栗子妈妈公号,<br>更多福利等着您~</div>" +
        "</div>" +
        "<div class='cancelButt'></div>";

    switch (state) {
        case 1:
            $(".wrap").html("");
            $(".wrap").html(leveOne);
            break;
        case 2:
            $(".wrap").html("");
            $(".wrap").html(leveTwo);
            break;
    }
    $(".cancelButt").get(0).addEventListener("touchstart", function(e) {
        e.preventDefault();
        $(".wrap").fadeOut();
    })
}

function QRcode() {
    $(".QRcode_wrap").fadeIn(0);
    $(".QRcode_wrap").html("");
    $(".QRcode_wrap").html("<div class='QRcode_inner'>" +
        "<img class='QRcode' src='images/QR-code.jpeg' style='width: 100%;padding-top: 220px;'>" +
        "</div>" +
        "<div class='QRcode_cancelButt'></div>");
    $(".QRcode_cancelButt").get(0).addEventListener("touchstart", function(e) {
        e.preventDefault();
        $(".QRcode_wrap").fadeOut(0);
    })
}

// 抽奖结果显示
function lotteryResult(resultCode){
    console.log(resultCode)
    $(".wrap").fadeIn();
    // resultCode=000：活动未开始
    // resultCode=001：未中奖
    // resultCode=002：一等奖
    // resultCode=003：二等奖
    // resultCode=004：三等奖
    // resultCode=005：四等奖
    // 未中奖
    var num='';
    var imgPath=''
    if(resultCode=='002'){
        num='一';
        imgPath='images/levelOne.png';
    }else if(resultCode=='003'){
        num='二'
        imgPath='images/levelTwo.png';
    }else if(resultCode=='004'){
        num='三'
        imgPath='images/levelThere.png';
    }else if(resultCode=='005'){
        num='四';
        imgPath='images/levelFour.png';
    }
    var notWin="<div class='resultBox'>"+
        "<div class='resultTitle defaultColor'>真遗憾，您没中奖</div>"+
        "<div class='resultImg'>"+
        "<img class='failedImg' src='images/notWin.png'/>"+
        "</div>"+
        "<div class='resultFoot'>"+
        "<p class='resultTip'>感谢您的参与！</p>"+
        "<p class='resultTip'>请继续关注“有栗”，</p>"+
        "<p class='resultTip'>更多活动等着你～</p>"+
        "</div>"+
        "<div class='cancelButton'></div>"+
        '</div>';
    // 查询未开启;
    var notStart="<div class='resultBox'>"+
        "<div class='errorTip'>"+
        "<p class='defaultColor'>抱歉，</p>"+
        "<p class='defaultColor'>查询功能还未开启。</p>"+
        "</div>"+
        "<div class='startTip'>"+
        "<p class='resultTip'>请于活动结束后（1月10日）</p>"+
        "<p class='resultTip'>查询中奖信息。</p>"+
        "</div>"+
        "<div class='cancelButton'></div>"+
        "</div>"
    // 中奖等级（1，2，3，4）
    var luck="<div class='resultBox'>"+
    "<div class='resultTitle'>"+
    "<p class='defaultColor'>恭喜您获得"+num+"等奖，</p>"+
    "<p class='defaultColor giveTip'>我们会尽快将奖品寄出。</p>"+
    "</div>"+
    "<div class='resultImg resultSuccess'>"+
    "<em class='successImg' style='background:url("+imgPath+") no-repeat center;background-size:cover'>"+
    "</em>"+
    "</div>"+
    "<div class='resultFoot'>"+
    "<p class='resultTip'>感谢您的参与！</p>"+
    "<p class='resultTip'>请继续关注“有栗”。</p>"+
    "</div>"+
    "<div class='cancelButton'></div>"+
    '</div>';
    if(resultCode=='000'){
        $(".wrap").html(notStart);
    }else if(resultCode=='001'){
        $(".wrap").html(notWin);
    }else{
        $(".wrap").html(luck);
    }
    $('.cancelButton').click(function (e) {
        e.preventDefault();
        $(".wrap").fadeOut();
    })
}