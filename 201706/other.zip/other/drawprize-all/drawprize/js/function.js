/**
 * Created by walter on 10/26/16.
 */

function dataLoad(filename)  {
    var arraydata;
    $.ajax({
        type: "GET",
        url: filename,
        dataType: "json",
        async: false,
        success: function(json) {arraydata = eval(json) }
    });
    return arraydata;
}
function GetQueryString(name)
{
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)
        return  (r[2]);
    return null;
}
function checkMobile(str,string) {
    var re = /^1\d{10}$/;
    if (re.test(str)&&checkName(string)) {

        return true;
    } else {
        alert("您输入的电话号码格式不正确!");
        return false;
    }
}
function checkName(str){
    if(str.length>0){
        return true;
    }else {
        alert("您输入的姓名不能为空!");
        return false;
    }
}
function prizeLeve(state,id){
    $(".wrap").fadeIn();
    const leveOne = "<div class='inner'>" +
        "<div class='innerHeader'>金牌大奖</div>" +
        "<div class='LeveOneTag'></div>" +
        "<div class='innerFooter' style='margin-top: '>厉害了,word天!特等奖都能抽到!恭喜恭喜!您将获得好奇一年份纸尿裤!我们将尽快联系你确认所需尺寸并速度邮寄~</div>" +
        "</div>" +
        "<div class='cancelButt'></div>";
    const leveTwo = "<div class='inner'>" +
        "<div class='innerHeader'>恭喜宝妈中奖啦!</div>" +
        "<div class='LeveTwoTag'></div>" +
        "<div class='innerFooter'>请在下方按钮领取京东优惠券,纸尿裤我们会以最快的速度发送给您~</div>" +
        "<div class='getCoupon'>点击领取京东优惠券</div>" +
        "</div>" +
        "<div class='cancelButt'></div>";
    const leveThree = "<div class='inner'>" +
        "<div class='innerHeader'>真遗憾</div>" +
        "<div class='LeveThreeTag'></div>" +
        "<div class='innerFooter'>感谢宝妈们对好奇的支持!关注好奇官方微信,加入金牌妈妈,赢取更多福利~</div>" +
        "</div>" +
        "<div class='cancelButt'></div>";
    if(state == 1){
        $(".wrap").html("")
        $(".wrap").html(leveOne);
    }else if (state == 2){
        $(".wrap").html("")
        $(".wrap").html(leveTwo);
        $(".getCoupon").get(0).addEventListener("touchstart",function (e) {
            e.preventDefault();
            $(this).addClass("pressClass");
        })
        $(".getCoupon").get(0).addEventListener("touchend",function (e) {
            e.preventDefault();
            $(this).removeClass("pressClass");
            window.location.href = "getCoupon.html?item="+id
        })
    }else {
        $(".wrap").html("")
        $(".wrap").html(leveThree);
    }
    $(".cancelButt").get(0).addEventListener("click",function (e) {
        e.preventDefault();
        $(".wrap").fadeOut();
    })
}